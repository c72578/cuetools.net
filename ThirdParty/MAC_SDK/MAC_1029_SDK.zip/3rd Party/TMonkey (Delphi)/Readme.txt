TMonkey Delphi Class for analyzing APE files

Sumbitted by Jurgen Faul ( jfaul@gmx.de )

(note: this does not directly use the MAC SDK, so it is not guaranteed to work with future APE files)